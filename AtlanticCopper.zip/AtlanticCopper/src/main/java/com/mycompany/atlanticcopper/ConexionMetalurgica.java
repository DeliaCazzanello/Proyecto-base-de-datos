package com.mycompany.atlanticcopper;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author win11
 */
public class ConexionMetalurgica {
    
    Connection conexion = null;
    
    String usuario = "root";
    String clave = "oliver666";
    String bd = "metalmecanico";
    String ip = "localhost";
    String puerto = ":3306";
    
    String cadena = "jdbc:mysql://"+ip+puerto+"/"+bd;
    
    public Connection estableceConexion(){
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(cadena, usuario, clave);
            //JOptionPane.showMessageDialog(null,"La conexcion se ha realizado correctamente");
            
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al conectarse a Ia base de datos,erro: "+ e.toString() );
        }
        return conexion;
    
    }

    Statement createStatement() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    ResultSet executeQuery(String consulta, String u, String c) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
