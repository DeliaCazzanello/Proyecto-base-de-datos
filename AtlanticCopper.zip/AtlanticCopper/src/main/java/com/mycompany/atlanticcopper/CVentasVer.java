/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atlanticcopper;

/**
 *
 * @author Win11
 */
import java.sql.CallableStatement;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class CVentasVer {
        
    String estacionVenta ;
    String fechaVenta ;
    String IDventa;

    public String getEstacionVenta() {
        return estacionVenta;
    }

    public void setEstacionVenta(String estacionVenta) {
        this.estacionVenta = estacionVenta;
    }
    
    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }
    
    public String getIDVenta() {
        return IDventa;
    }

    public void setIDVenta(String IDventa) {
        this.IDventa = IDventa;
    }
    
    public void InsertarVenta(JTextField paramtxt_estacion_venta, JTextField paramtxt_fecha_venta){
       
       setEstacionVenta(paramtxt_estacion_venta.getText());
       setFechaVenta(paramtxt_fecha_venta.getText());
       
       ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
       
       String consulta=("INSERT INTO ventas (estacion, fecha)values(?,?);");
       
       try{
           
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
           cs.setString(1, getEstacionVenta());
           cs.setString(2, getFechaVenta());
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
           
       } catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error, fallo en la inseción de datos. Descripcion: "+e.toString());
       }
       
    }
    
    public void Modificar(JTable paramtabla_ventas) {
    int fila = paramtabla_ventas.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Por favor selecciona un producto de la tabla");
        return;
    }
    
    String fecha = paramtabla_ventas.getValueAt(fila, 1).toString();
    String estacion = paramtabla_ventas.getValueAt(fila, 2).toString();
    String id = paramtabla_ventas.getValueAt(fila, 0).toString();

    ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
    String consulta = "UPDATE ventas SET fecha=?, estacion=? WHERE ID_venta='"+id+"'";

    try (Connection con = objetoConexion.estableceConexion(); CallableStatement cs = con.prepareCall(consulta)) {
        cs.setString(1, estacion);
        cs.setString(2, fecha);
        
        int filasActualizadas = cs.executeUpdate(); // Cambiar a executeUpdate para actualizaciones.
        
        if (filasActualizadas > 0) {
            JOptionPane.showMessageDialog(null, "Datos actualizados correctamente");
        } else {
            JOptionPane.showMessageDialog(null, "No se actualizó ningún dato. Verifica que el ID exista.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error, fallo en la actualización de datos. Descripción: " + e.toString());
    }
}
        
      public void EliminarRegistro(JTable paramtabla_ventas){
        int fila = paramtabla_ventas.getSelectedRow();
        String valor =paramtabla_ventas.getValueAt(fila,0).toString();
        ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
        
        String consulta=("DELETE FROM ventas WHERE ID_venta='"+valor+"'");
       
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        Statement st;
        
        try{
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.execute();
        }catch(Exception e){
        }
    }
    
    
   /* public void RellenarComboBox(String tabla, String valor, JComboBox ID_ventas){
    String sql = "Select * from " + tabla;
    Statement st;
    ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
    try{
        st= objetoConexion.estableceConexion().createStatement();
        ResultSet rs = st.executeQuery(sql);
        while(rs.next())
        {
            ID_ventas.addItem(rs.getString(valor));
        }
    } catch(Exception e){
        JOptionPane.showMessageDialog(null,"No se pudo mostar los registro de la BD"+e.toString());
    }
}*/
    
    public void MostrarVentas(JTable paramtabla_ventas){
        ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        
        String sql="";
        
        modelo.addColumn("ID venta");
        modelo.addColumn("Estacion venta");
        modelo.addColumn("Fecha venta");
        paramtabla_ventas.setRowSorter(OrdenarTabla);
        sql ="SELECT * FROM ventas";
        
        String[] datos = new String[3];
        Statement st;
        
        try{
            st= objetoConexion.estableceConexion().createStatement();
            
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                
                modelo.addRow(datos);
            }
            
            paramtabla_ventas.setModel(modelo);
            
        } catch(Exception e){
            JOptionPane.showMessageDialog(null,"No se pudo mostar los registro de la BD");
        }
        
    }
}
