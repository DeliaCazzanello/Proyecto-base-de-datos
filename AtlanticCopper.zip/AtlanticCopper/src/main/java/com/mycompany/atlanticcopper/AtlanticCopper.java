/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atlanticcopper;

/**
 *
 * @author Win11
 */
public class AtlanticCopper {

    public static void main(String[] args) {
        Login_registrarse objetoLogin = new Login_registrarse();
        objetoLogin.setVisible(true);  
        //MenuPrincipalUsuario objetoMenu = new MenuPrincipalUsuario();
        //objetoMenu.setVisible(true);
    }
}
