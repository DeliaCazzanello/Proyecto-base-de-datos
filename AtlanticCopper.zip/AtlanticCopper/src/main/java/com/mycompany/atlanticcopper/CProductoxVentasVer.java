/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atlanticcopper;

/**
 *
 * @author Win11
 */
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class CProductoxVentasVer {
    
    String IDproductoxventa;
    String IDproducto ;
    String IDventa ;
    String CantidadVenta;
    String PrecioVenta;
    
    public String getIDProductoxventa() {
        return IDproductoxventa;
    }

    public void setIDProductoxventa(String IDproductoxventa) {
        this.IDproductoxventa = IDproductoxventa;
    }

    public String getIDProducto() {
        return IDproducto;
    }

    public void setIDProducto(String IDproducto) {
        this.IDproducto = IDproducto;
    }
    
    public String getIDVenta() {
        return IDventa;
    }

    public void setIDVenta(String IDventa) {
        this.IDventa = IDventa;
    }
    public String getCantidadVenta() {
        return CantidadVenta;
    }

    public void setCantidadVenta(String CantidadVenta) {
        this.CantidadVenta = CantidadVenta;
    }
    public String getPrecioVenta() {
        return PrecioVenta;
    }

    public void setPrecioVenta(String PrecioVenta) {
        this.PrecioVenta = PrecioVenta;
    }

    
    public void InsertarVenta(JComboBox paramID_productos, JComboBox paramID_ventas, JTextField paramtxt_cantidad, JTextField paramtxt_precio){
       setIDProducto(paramID_productos.getSelectedItem().toString());
       setIDVenta( paramID_ventas.getSelectedItem().toString());
       setCantidadVenta(paramtxt_cantidad.getText());
       setPrecioVenta(paramtxt_precio.getText());
       
       ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
       
       String consulta=("INSERT INTO productoxventas (ID_producto, ID_venta, cantidad, precio)values(?,?,?,?);");
       
       try{
           
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
           cs.setString(1, getIDProducto());
           cs.setString(2, getIDVenta());
           cs.setString(3, getCantidadVenta());
           cs.setString(4, getPrecioVenta());
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
           
       } catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error, fallo en la inseción de datos. Descripcion: "+e.toString());
       }
       
    }
    
    public void RellenarComboBox(String tabla, String valor, JComboBox ID_productos){
    String sql = "Select * from " + tabla;
    Statement st;
    ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
    try{
        st= objetoConexion.estableceConexion().createStatement();
        ResultSet rs = st.executeQuery(sql);
        while(rs.next())
        {
            ID_productos.addItem(rs.getString(valor));
        }
    } catch(Exception e){
        JOptionPane.showMessageDialog(null,"No se pudo mostar los registro de la BD"+e.toString());
    }
    }
    
    public void RellenarComboBox2(String tabla, String valor, JComboBox ID_ventas){
    String sql = "Select * from " + tabla;
    Statement st;
    ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
    try{
        st= objetoConexion.estableceConexion().createStatement();
        ResultSet rs = st.executeQuery(sql);
        while(rs.next())
        {
            ID_ventas.addItem(rs.getString(valor));
        }
    } catch(Exception e){
        JOptionPane.showMessageDialog(null,"No se pudo mostar los registro de la BD"+e.toString());
    }
}
    
    public void EliminarRegistro(JTable paramtabla_productoxventas){
        int fila = paramtabla_productoxventas.getSelectedRow();
        String valor =paramtabla_productoxventas.getValueAt(fila,4).toString();
        ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
        
        String consulta=("DELETE FROM productoxventas WHERE ID_productoxventas='"+valor+"'");
       
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        Statement st;
        
        try{
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.execute();
        }catch(Exception e){
        }
    }
    
    
    public void Modificar(JTable paramtabla_productoxventas) {
    int fila = paramtabla_productoxventas.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Por favor selecciona un producto de la tabla");
        return;
    }
    
    String id_producto = paramtabla_productoxventas.getValueAt(fila, 0).toString();
    String id_venta = paramtabla_productoxventas.getValueAt(fila, 1).toString();
    String cantidad = paramtabla_productoxventas.getValueAt(fila, 2).toString();
    String precio = paramtabla_productoxventas.getValueAt(fila, 3).toString();
    String id_productoxventas = paramtabla_productoxventas.getValueAt(fila, 4).toString();

    ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
    String consulta = "UPDATE productoxventas SET ID_producto=?, ID_venta=?, cantidad=?, precio=? WHERE ID_productoxventas=?";

    try (Connection con = objetoConexion.estableceConexion(); CallableStatement cs = con.prepareCall(consulta)) {
        cs.setString(1, id_producto);
        cs.setString(2, id_venta);
        cs.setString(3, cantidad);
        cs.setString(4, precio);
        cs.setString(5, id_productoxventas);
        
        int filasActualizadas = cs.executeUpdate(); // Cambiar a executeUpdate para actualizaciones.
        
        if (filasActualizadas > 0) {
            JOptionPane.showMessageDialog(null, "Datos actualizados correctamente");
        } else {
            JOptionPane.showMessageDialog(null, "No se actualizó ningún dato. Verifica que el ID exista.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error, fallo en la actualización de datos. Descripción: " + e.toString());
    }
}

    
    public void MostrarProductoxVentas(JTable paramtabla_productoxventas){
        ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        
        String sql="";
        
        modelo.addColumn("ID producto");
        modelo.addColumn("ID venta");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Precio");
        modelo.addColumn("ID productoxventa");
        paramtabla_productoxventas.setRowSorter(OrdenarTabla);
        sql ="SELECT * FROM productoxventas";
        
        String[] datos = new String[5];
        Statement st;
        
        try{
            st= objetoConexion.estableceConexion().createStatement();
            
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                
                modelo.addRow(datos);
            }
            
            paramtabla_productoxventas.setModel(modelo);
            
        } catch(Exception e){
            JOptionPane.showMessageDialog(null,"No se pudo mostar los registro de la BD");
        }
        
    }
}
