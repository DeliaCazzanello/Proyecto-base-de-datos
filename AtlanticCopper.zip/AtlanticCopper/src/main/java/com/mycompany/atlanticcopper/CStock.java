/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atlanticcopper;

import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author Win11
 */
public class CStock {
    String nombreProducto ;
    String IDProducto;
    String stock;
    
    public String getIDProducto() {
        return IDProducto;
    }

    public void setIDProducto(String IDProducto) {
        this.IDProducto = IDProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }
    
    public String getStockProductos() {
        return stock;
    }

    public void setStockProducto(String stock) {
        this.stock = stock;
    }

    public void MostrarProductos(JTable paramtabla_productostock){
        ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        
        String sql="";
        
        modelo.addColumn("Nombre Producto");
        modelo.addColumn("ID Producto");
        modelo.addColumn("Stock Producto");
        paramtabla_productostock.setRowSorter(OrdenarTabla);
        sql ="SELECT * FROM productos";
        
        String[] datos = new String[3];
        Statement st;
        
        try{
            st= objetoConexion.estableceConexion().createStatement();
            
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                
                modelo.addRow(datos);
            }
            
            paramtabla_productostock.setModel(modelo);
            
        } catch(Exception e){
            JOptionPane.showMessageDialog(null,"No se pudo mostar los registro de la BD");
        }
        
    }
}
