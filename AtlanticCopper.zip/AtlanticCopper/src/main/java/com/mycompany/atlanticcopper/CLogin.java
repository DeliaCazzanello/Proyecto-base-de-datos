/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atlanticcopper;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author Win11
 */
public class CLogin {
    String nombreUsuario ;
    String contraseniaUsuario;
    String privilegio;
    
    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContraseniaUsuario() {
        return contraseniaUsuario;
    }

    public void setContraseniaUsuario(String contraseniaUsuario) {
        this.contraseniaUsuario = contraseniaUsuario;
    }
    
    public String getPrivilegioUsuario() {
        return privilegio;
    }

    public void setPrivilegioUsuario(String privilegio) {
        this.privilegio = privilegio;
    }
    
    
    public void InsertarUsuario(JTextField paramusuario, JPasswordField paramcontrasenia){
       
       setNombreUsuario(paramusuario.getText());
       setContraseniaUsuario(String.valueOf(paramcontrasenia.getPassword()));
       
       ConexionUsuarios objetoConexion = new ConexionUsuarios();
       
       String consulta=("INSERT INTO usuarios(nombre_usuario, contrasenia_usuario, privilegio) values(?,?,'usuario');");
       
       try{
           
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
           cs.setString(1, getNombreUsuario());
           cs.setString(2, getContraseniaUsuario());
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
           
           
       } catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error, fallo en la inseción de datos. Descripcion: "+e.toString());
       }
    }
    
    public void EliminarRegistro(JTable paramtabla_usuarios){
        int fila = paramtabla_usuarios.getSelectedRow();
        String nombre =paramtabla_usuarios.getValueAt(fila,1).toString();
        String contrasenia =paramtabla_usuarios.getValueAt(fila,2).toString();
        ConexionUsuarios objetoConexion = new ConexionUsuarios();
        
        String consulta=("DELETE FROM usuarios WHERE nombre_usuario='"+nombre+"' AND contrasenia_usuario='"+contrasenia+"'");
       
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        Statement st;
        
        try{
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.execute();
        }catch(Exception e){
        }
    }
    
    
    public String validarDatos(JTextField usuario, JPasswordField contrasenia) {
    ConexionUsuarios objetoConexion = new ConexionUsuarios();
    
    String resultado = null; // Para almacenar el resultado de la validación
    try {
        objetoConexion.estableceConexion();
        String u = usuario.getText();
        String c = String.valueOf(contrasenia.getPassword());

        // Usar PreparedStatement para evitar inyección SQL
        String sql = "SELECT privilegio FROM usuarios WHERE nombre_usuario = ? AND contrasenia_usuario = ?";
        PreparedStatement preparedStatement = objetoConexion.estableceConexion().prepareStatement(sql);
        preparedStatement.setString(1, u);
        preparedStatement.setString(2, c);
        
        ResultSet rs = preparedStatement.executeQuery();

        // Verifica si hay resultados
        if (rs.next()) {
            // Obtiene el valor de privilegio
            String rol = rs.getString("privilegio");

            // Realiza la validación
            resultado = switch (rol) {
                case "usuario" -> "usuario";
                case "admin" -> "admin";
                default -> "desconocido";
            };
        } else {
            resultado = "incorrecto"; // Usuario o contraseña incorrectos
        }

        rs.close();
        preparedStatement.close();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
    } 

    return resultado;
}

public void MostrarUsuarios(JTable paramtabla_usuarios){
        ConexionUsuarios objetoConexion = new ConexionUsuarios();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        
        String sql="";
        
        modelo.addColumn("Privilegio Usuario");
        modelo.addColumn("Nombre Usuario");
        modelo.addColumn("Contraseña Usuario");
        paramtabla_usuarios.setRowSorter(OrdenarTabla);
        sql = "SELECT * FROM usuarios";
        
        String[] datos = new String[3];
        Statement st;
        
        try{
            st= objetoConexion.estableceConexion().createStatement();
            
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                
                modelo.addRow(datos);
            }
            
            paramtabla_usuarios.setModel(modelo);
            
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null,"No se pudo mostar los registro de la BD");
        }
        
    }


public void Modificar(JTable paramtabla_usuarios) {
    int fila = paramtabla_usuarios.getSelectedRow();
   if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Por favor selecciona un producto de la tabla");
        return;
    }
    
    String privilegios = paramtabla_usuarios.getValueAt(fila, 0).toString();
    String nombre = paramtabla_usuarios.getValueAt(fila, 1).toString();
    String contrasenia = paramtabla_usuarios.getValueAt(fila, 2).toString();

    ConexionUsuarios objetoConexion = new ConexionUsuarios();
    String consulta = "UPDATE usuarios SET privilegio=? WHERE nombre_usuario=? and contrasenia_usuario=?"; 

    try (Connection con = objetoConexion.estableceConexion(); CallableStatement cs = con.prepareCall(consulta)) {
        cs.setString(1, privilegios);
        cs.setString(2, nombre);
        cs.setString(3, contrasenia);
        
        int filasActualizadas = cs.executeUpdate(); // Cambiar a executeUpdate para actualizaciones.
        
        if (filasActualizadas > 0) {
            JOptionPane.showMessageDialog(null, "Datos actualizados correctamente");
        } else {
            JOptionPane.showMessageDialog(null, "No se actualizó ningún dato. Verifica que el ID exista.");
        }                                                                                           
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error, fallo en la actualización de datos. Descripción: " + e.toString());
    }
}
}




