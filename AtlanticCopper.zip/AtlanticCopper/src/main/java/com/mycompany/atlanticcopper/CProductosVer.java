/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atlanticcopper;

/**
 *
 * @author Win11
 */
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class CProductosVer {
    
    
    String nombreProducto ;
    String IDProducto;
    
    public String getIDProducto() {
        return IDProducto;
    }

    public void setIDProducto(String IDProducto) {
        this.IDProducto = IDProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    
    public void InsertarProducto(JTextField paramtxt_nombre_producto){
       
       setNombreProducto(paramtxt_nombre_producto.getText());
       
       ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
       
       String consulta=("INSERT INTO productos (nombre_producto, stock)values(?,0);");
       
       try{
           
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
           cs.setString(1, getNombreProducto());
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
           
       } catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error, fallo en la inseción de datos. Descripcion: "+e.toString());
       }
       
       
       
    }
    
    public void Modificar(JTable paramtabla_productos) {
    int fila = paramtabla_productos.getSelectedRow();
   if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Por favor selecciona un producto de la tabla");
        return;
    }
    
    String nombre = paramtabla_productos.getValueAt(fila, 0).toString();
    String id_producto = paramtabla_productos.getValueAt(fila, 1).toString();

    ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
    String consulta = "UPDATE productos SET nombre_producto=? WHERE ID_producto=?"; 

    try (Connection con = objetoConexion.estableceConexion(); CallableStatement cs = con.prepareCall(consulta)) {
        cs.setString(1, nombre);
        cs.setString(2, id_producto);
        
        int filasActualizadas = cs.executeUpdate(); // Cambiar a executeUpdate para actualizaciones.
        
        if (filasActualizadas > 0) {
            JOptionPane.showMessageDialog(null, "Datos actualizados correctamente");
        } else {
            JOptionPane.showMessageDialog(null, "No se actualizó ningún dato. Verifica que el ID exista.");
        }                                                                                           
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error, fallo en la actualización de datos. Descripción: " + e.toString());
    }
}
    
     public void EliminarRegistro(JTable paramtabla_productos){
        int fila = paramtabla_productos.getSelectedRow();
        String valor =paramtabla_productos.getValueAt(fila,1).toString();
        ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
        
        String consulta=("DELETE FROM productos WHERE ID_producto='"+valor+"'");
       
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        Statement st;
        
        try{
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.execute();
        }catch(Exception e){
        }
    }
    
     /*public void RellenarComboBox(String tabla, String valor, JComboBox ID_productos){
    String sql = "Select * from " + tabla;
    Statement st;
    ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
    try{
        st= objetoConexion.estableceConexion().createStatement();
        ResultSet rs = st.executeQuery(sql);
        while(rs.next())
        {
            ID_productos.addItem(rs.getString(valor));
        }
    } catch(Exception e){
        JOptionPane.showMessageDialog(null,"No se pudo mostar los registro de la BD"+e.toString());
    }
    }*/
    
    public void MostrarProductos(JTable paramtabla_productos){
        ConexionMetalurgica objetoConexion = new ConexionMetalurgica();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        
        String sql="";
        
        modelo.addColumn("Nombre Producto");
        modelo.addColumn("ID Producto");
        paramtabla_productos.setRowSorter(OrdenarTabla);
        sql ="SELECT * FROM productos";
        
        String[] datos = new String[2];
        Statement st;
        
        try{
            st= objetoConexion.estableceConexion().createStatement();
            
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                
                modelo.addRow(datos);
            }
            
            paramtabla_productos.setModel(modelo);
            
        } catch(Exception e){
            JOptionPane.showMessageDialog(null,"No se pudo mostar los registro de la BD");
        }
        
    }
}
